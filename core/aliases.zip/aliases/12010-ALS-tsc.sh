#!/bin/bash

alias tscx='npx tsc'
alias tscw='npx tsc --watch'
