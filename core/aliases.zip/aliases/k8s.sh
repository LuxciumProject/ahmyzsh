#!/bin/bash

alias k="kubectl"
