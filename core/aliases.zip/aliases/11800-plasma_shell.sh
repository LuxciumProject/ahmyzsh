#!/bin/bash

alias restart-panel="(killall plasmashell && plasmashell & disown)"
