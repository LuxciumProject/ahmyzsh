#!/bin/bash

alias cht='env PAGER="/usr/bin/less -Ks" cht.sh --shell'
