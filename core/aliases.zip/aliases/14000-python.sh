#!/bin/bash

alias python='python3'
