#!/bin/bash

alias killshot='kill $(pidof shotwell)'

alias restartplasma="kquitapp5 plasmashell && kstart5 plasmashell"
# plasmashell --replace
