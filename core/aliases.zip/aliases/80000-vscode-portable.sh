#!/usr/bin/bash

alias get-vscode-stable="wget https://code.visualstudio.com/sha/download?build=stable&os=linux-x64"
