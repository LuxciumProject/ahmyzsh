#!/bin/bash

# function exclude_azure-cli() {
#   echo 'exclude: azure-cli'
#   mv /etc/yum.repos.d/azure-cli.repo /etc/yum.repos.d/azure-cli.repo.off
#   #$@!
# }

# function include_azure-cli() {
#   echo 'include: azure-cli'
#   mv /etc/yum.repos.d/azure-cli.repo.off /etc/yum.repos.d/azure-cli.repo
#   #$%
# }
# function exclude_bintray-ookla-rhel() {
#   echo 'exclude: bintray-ookla-rhel'
#   mv /etc/yum.repos.d/bintray-ookla-rhel.repo /etc/yum.repos.d/bintray-ookla-rhel.repo.off
#   #$@!
# }

# function include_bintray-ookla-rhel() {
#   echo 'include: bintray-ookla-rhel'
#   mv /etc/yum.repos.d/bintray-ookla-rhel.repo.off /etc/yum.repos.d/bintray-ookla-rhel.repo
#   #$%
# }
# function exclude__copr_phracek-PyCharm() {
#   echo 'exclude: _copr_phracek-PyCharm'
#   mv /etc/yum.repos.d/_copr_phracek-PyCharm.repo /etc/yum.repos.d/_copr_phracek-PyCharm.repo.off
#   #$@!
# }

# function include__copr_phracek-PyCharm() {
#   echo 'include: _copr_phracek-PyCharm'
#   mv /etc/yum.repos.d/_copr_phracek-PyCharm.repo.off /etc/yum.repos.d/_copr_phracek-PyCharm.repo
#   #$%
# }
# function exclude_docker-ce() {
#   echo 'exclude: docker-ce'
#   mv /etc/yum.repos.d/docker-ce.repo /etc/yum.repos.d/docker-ce.repo.off
#   #$@!
# }

# function include_docker-ce() {
#   echo 'include: docker-ce'
#   mv /etc/yum.repos.d/docker-ce.repo.off /etc/yum.repos.d/docker-ce.repo
#   #$%
# }
# function exclude_fedora-cisco-openh264() {
#   echo 'exclude: fedora-cisco-openh264'
#   mv /etc/yum.repos.d/fedora-cisco-openh264.repo /etc/yum.repos.d/fedora-cisco-openh264.repo.off
#   #$@!
# }

# function include_fedora-cisco-openh264() {
#   echo 'include: fedora-cisco-openh264'
#   mv /etc/yum.repos.d/fedora-cisco-openh264.repo.off /etc/yum.repos.d/fedora-cisco-openh264.repo
#   #$%
# }
# function exclude_fedora-updates-testing-modular() {
#   echo 'exclude: fedora-updates-testing-modular'
#   mv /etc/yum.repos.d/fedora-updates-testing-modular.repo /etc/yum.repos.d/fedora-updates-testing-modular.repo.off
#   #$@!
# }

# function include_fedora-updates-testing-modular() {
#   echo 'include: fedora-updates-testing-modular'
#   mv /etc/yum.repos.d/fedora-updates-testing-modular.repo.off /etc/yum.repos.d/fedora-updates-testing-modular.repo
#   #$%
# }
# function exclude_fedora-updates-testing() {
#   echo 'exclude: fedora-updates-testing'
#   mv /etc/yum.repos.d/fedora-updates-testing.repo /etc/yum.repos.d/fedora-updates-testing.repo.off
#   #$@!
# }

# function include_fedora-updates-testing() {
#   echo 'include: fedora-updates-testing'
#   mv /etc/yum.repos.d/fedora-updates-testing.repo.off /etc/yum.repos.d/fedora-updates-testing.repo
#   #$%
# }
# function exclude_gh-cli() {
#   echo 'exclude: gh-cli'
#   mv /etc/yum.repos.d/gh-cli.repo /etc/yum.repos.d/gh-cli.repo.off
#   #$@!
# }

# function include_gh-cli() {
#   echo 'include: gh-cli'
#   mv /etc/yum.repos.d/gh-cli.repo.off /etc/yum.repos.d/gh-cli.repo
#   #$%
# }
# function exclude_google-chrome-beta() {
#   echo 'exclude: google-chrome-beta'
#   mv /etc/yum.repos.d/google-chrome-beta.repo /etc/yum.repos.d/google-chrome-beta.repo.off
#   #$@!
# }

# function include_google-chrome-beta() {
#   echo 'include: google-chrome-beta'
#   mv /etc/yum.repos.d/google-chrome-beta.repo.off /etc/yum.repos.d/google-chrome-beta.repo
#   #$%
# }
# function exclude_google-chrome() {
#   echo 'exclude: google-chrome'
#   mv /etc/yum.repos.d/google-chrome.repo /etc/yum.repos.d/google-chrome.repo.off
#   #$@!
# }

# function include_google-chrome() {
#   echo 'include: google-chrome'
#   mv /etc/yum.repos.d/google-chrome.repo.off /etc/yum.repos.d/google-chrome.repo
#   #$%
# }
# function exclude_google-chrome-unstable() {
#   echo 'exclude: google-chrome-unstable'
#   mv /etc/yum.repos.d/google-chrome-unstable.repo /etc/yum.repos.d/google-chrome-unstable.repo.off
#   #$@!
# }

# function include_google-chrome-unstable() {
#   echo 'include: google-chrome-unstable'
#   mv /etc/yum.repos.d/google-chrome-unstable.repo.off /etc/yum.repos.d/google-chrome-unstable.repo
#   #$%
# }
# function exclude_microsoft-insiders-fast() {
#   echo 'exclude: microsoft-insiders-fast'
#   mv /etc/yum.repos.d/microsoft-insiders-fast.repo /etc/yum.repos.d/microsoft-insiders-fast.repo.off
#   #$@!
# }

# function include_microsoft-insiders-fast() {
#   echo 'include: microsoft-insiders-fast'
#   mv /etc/yum.repos.d/microsoft-insiders-fast.repo.off /etc/yum.repos.d/microsoft-insiders-fast.repo
#   #$%
# }
# function exclude_microsoft-insiders-slow() {
#   echo 'exclude: microsoft-insiders-slow'
#   mv /etc/yum.repos.d/microsoft-insiders-slow.repo /etc/yum.repos.d/microsoft-insiders-slow.repo.off
#   #$@!
# }

# function include_microsoft-insiders-slow() {
#   echo 'include: microsoft-insiders-slow'
#   mv /etc/yum.repos.d/microsoft-insiders-slow.repo.off /etc/yum.repos.d/microsoft-insiders-slow.repo
#   #$%
# }
# function exclude_microsoft-prod() {
#   echo 'exclude: microsoft-prod'
#   mv /etc/yum.repos.d/microsoft-prod.repo /etc/yum.repos.d/microsoft-prod.repo.off
#   #$@!
# }

# function include_microsoft-prod() {
#   echo 'include: microsoft-prod'
#   mv /etc/yum.repos.d/microsoft-prod.repo.off /etc/yum.repos.d/microsoft-prod.repo
#   #$%
# }
# function exclude_mongodb-org-4.4() {
#   echo 'exclude: mongodb-org-4'
#   mv /etc/yum.repos.d/mongodb-org-4.4.repo /etc/yum.repos.d/mongodb-org-4.4.repo.off
#   #$@!
# }

# function include_mongodb-org-4.4() {
#   echo 'include: mongodb-org-4'
#   mv /etc/yum.repos.d/mongodb-org-4.4.repo.off /etc/yum.repos.d/mongodb-org-4.4.repo
#   #$%
# }
# function exclude_rpmfusion-free-updates-testing() {
#   echo 'exclude: rpmfusion-free-updates-testing'
#   mv /etc/yum.repos.d/rpmfusion-free-updates-testing.repo /etc/yum.repos.d/rpmfusion-free-updates-testing.repo.off
#   #$@!
# }

# function include_rpmfusion-free-updates-testing() {
#   echo 'include: rpmfusion-free-updates-testing'
#   mv /etc/yum.repos.d/rpmfusion-free-updates-testing.repo.off /etc/yum.repos.d/rpmfusion-free-updates-testing.repo
#   #$%
# }
# function exclude_rpmfusion-nonfree-nvidia-driver() {
#   echo 'exclude: rpmfusion-nonfree-nvidia-driver'
#   mv /etc/yum.repos.d/rpmfusion-nonfree-nvidia-driver.repo /etc/yum.repos.d/rpmfusion-nonfree-nvidia-driver.repo.off
#   #$@!
# }

# function include_rpmfusion-nonfree-nvidia-driver() {
#   echo 'include: rpmfusion-nonfree-nvidia-driver'
#   mv /etc/yum.repos.d/rpmfusion-nonfree-nvidia-driver.repo.off /etc/yum.repos.d/rpmfusion-nonfree-nvidia-driver.repo
#   #$%
# }
# function exclude_rpmfusion-nonfree-steam() {
#   echo 'exclude: rpmfusion-nonfree-steam'
#   mv /etc/yum.repos.d/rpmfusion-nonfree-steam.repo /etc/yum.repos.d/rpmfusion-nonfree-steam.repo.off
#   #$@!
# }

# function include_rpmfusion-nonfree-steam() {
#   echo 'include: rpmfusion-nonfree-steam'
#   mv /etc/yum.repos.d/rpmfusion-nonfree-steam.repo.off /etc/yum.repos.d/rpmfusion-nonfree-steam.repo
#   #$%
# }
# function exclude_rpmfusion-nonfree-updates-testing() {
#   echo 'exclude: rpmfusion-nonfree-updates-testing'
#   mv /etc/yum.repos.d/rpmfusion-nonfree-updates-testing.repo /etc/yum.repos.d/rpmfusion-nonfree-updates-testing.repo.off
#   #$@!
# }

# function include_rpmfusion-nonfree-updates-testing() {
#   echo 'include: rpmfusion-nonfree-updates-testing'
#   mv /etc/yum.repos.d/rpmfusion-nonfree-updates-testing.repo.off /etc/yum.repos.d/rpmfusion-nonfree-updates-testing.repo
#   #$%
# }
# function exclude_teamviewer() {
#   echo 'exclude: teamviewer'
#   mv /etc/yum.repos.d/teamviewer.repo /etc/yum.repos.d/teamviewer.repo.off
#   #$@!
# }

# function include_teamviewer() {
#   echo 'include: teamviewer'
#   mv /etc/yum.repos.d/teamviewer.repo.off /etc/yum.repos.d/teamviewer.repo
#   #$%
# }
# function exclude_vscode() {
#   echo 'exclude: vscode'
#   mv /etc/yum.repos.d/vscode.repo /etc/yum.repos.d/vscode.repo.off
#   #$@!
# }

# function include_vscode() {
#   echo 'include: vscode'
#   mv /etc/yum.repos.d/vscode.repo.off /etc/yum.repos.d/vscode.repo
#   #$%
# }

# function include_repos_() {
#   include_azure-cli
#   include_bintray-ookla-rhel
#   include__copr_phracek-PyCharm
#   include_docker-ce
#   include_fedora-cisco-openh264
#   include_fedora-updates-testing-modular
#   include_fedora-updates-testing
#   include_gh-cli
#   include_google-chrome-beta
#   include_google-chrome
#   include_google-chrome-unstable
#   include_microsoft-insiders-fast
#   include_microsoft-insiders-slow
#   include_microsoft-prod
#   include_mongodb-org-4.4
#   include_rpmfusion-free-updates-testing
#   include_rpmfusion-nonfree-nvidia-driver
#   include_rpmfusion-nonfree-steam
#   include_rpmfusion-nonfree-updates-testing
#   include_teamviewer
#   include_vscode
# }

# function exclude_repos_() {
#   exclude_azure-cli
#   exclude_bintray-ookla-rhel
#   exclude__copr_phracek-PyCharm
#   exclude_docker-ce
#   exclude_fedora-cisco-openh264
#   exclude_fedora-updates-testing-modular
#   exclude_fedora-updates-testing
#   exclude_gh-cli
#   exclude_google-chrome-beta
#   exclude_google-chrome
#   exclude_google-chrome-unstable
#   exclude_microsoft-insiders-fast
#   exclude_microsoft-insiders-slow
#   exclude_microsoft-prod
#   exclude_mongodb-org-4
#   exclude_rpmfusion-free-updates-testing
#   exclude_rpmfusion-nonfree-nvidia-driver
#   exclude_rpmfusion-nonfree-steam
#   exclude_rpmfusion-nonfree-updates-testing
#   exclude_teamviewer
#   exclude_vscode
# }
