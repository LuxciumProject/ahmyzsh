#!/bin/bash

alias mv_tg_img="mkdir tmbnails; mv *_thumb* ./tmbnails; mv_imgs"
alias tg_mv_img="mkdir tmbnails; mv *_thumb* ./tmbnails; mv_imgs"
