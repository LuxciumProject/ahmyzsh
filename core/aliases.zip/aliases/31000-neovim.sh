#!/usr/bin/bash

alias vim="nvim"
