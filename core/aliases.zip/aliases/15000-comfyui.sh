#!/usr/bin/env bash

# ComfyUI

alias ai_lab="conda activate ai_lab && cd /projects/sdxl-workspace;"
alias comfy="conda activate ai_lab && cd /projects/sdxl-workspace/ComfyUI/ && python /projects/sdxl-workspace/ComfyUI/main.py"
