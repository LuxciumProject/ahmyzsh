#!/bin/bash

function load_autocomplete() {
  source_ "${CORE_COMPLETE}/autocomplete.sh"
  load_autocomplete_
}
