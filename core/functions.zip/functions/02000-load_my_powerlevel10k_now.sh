#!/bin/bash

function load_my_powerlevel10k_now() {
  ## load_my_pl10K_layout_now
  source_ "${AHMYZSH}/themes/pl10K-Layout.zsh"
  load_my_powerlevel10k
  pl10k_prompt_on

}
