#!/bin/bash

function load_aliases() {
  call_ Load_all_files_d "${AHMYZSH_CORE}/aliases"
}
