(() => {
  console.log(!!false);
  //= > false
  console.log(!!undefined);
  //= > false
  console.log(!!null);
  //= > false
  console.log(!!'');
  //= > false
  console.log(!!0);
  //= > false
  console.log(!!NaN);
  //= > false
  console.log(!!false);
  //= > false
  console.log(typeof Boolean(undefined));
  //= > false
  console.log(typeof Boolean(null));
  //= > false
  console.log(typeof Boolean(''));
  //= > false
  console.log(typeof Boolean(0));
  //= > false
  console.log(typeof Boolean(NaN));
  //= > false
})();
