// connectMongoDB
const { MongoClient } = require('mongodb');
const config = require('../config/');

const connectionString = `${config.connectionString}testDB`;

const newParser = {
  useNewUrlParser: true,
};

MongoClient.connect(connectionString, newParser, (connectErr, db) => {
  if (!connectErr) {
    //
    db.collections('TestCollection').insertOne({
      Text: 'this is one of many tests',
      isImportantStuff: false,
    }, (insertErr, result) => {
      if (!insertErr) {
        return console.log(result);
      }
      return console.log('Error connecting DB:', insertErr.message);
    });
    //
    //
    return db.close();
  }
  return console.log('Error connecting DB:', connectErr.message);
});
