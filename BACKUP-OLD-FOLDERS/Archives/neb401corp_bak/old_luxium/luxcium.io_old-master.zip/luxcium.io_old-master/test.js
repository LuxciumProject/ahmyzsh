const _ = require('lodash');


_.noConflict();
console.log(_);
