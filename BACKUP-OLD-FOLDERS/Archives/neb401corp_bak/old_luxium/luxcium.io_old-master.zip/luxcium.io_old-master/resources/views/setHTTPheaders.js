module.exports = function setheader(res, next) {
  //
  res.setHeader('Connection', 'Transfer-Encoding');
  res.setHeader('Transfer-Encoding', 'chunked');
  res.setHeader('Cache-Control', 'public, max-age=864000');
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  //
  res.writeHead(200, {
    'Transfer-Encoding': 'chunked',
    'X-Content-Type-Options': 'nosniff',
  });
  next(res);
};
