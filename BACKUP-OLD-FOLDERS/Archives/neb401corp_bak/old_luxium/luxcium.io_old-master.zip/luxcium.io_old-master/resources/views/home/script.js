document.getElementById('topDate').innerText = new Date();
const btcQuantitybuyer = document.getElementById('btcQuantitybuyer');
const buyerInputCAD = document.getElementById('buyerInputCAD');
const btcQuantityseller = document.getElementById('btcQuantityseller');
const sellerInputCAD = document.getElementById('sellerInputCAD');
const quadrigaCADbuy = document.getElementById('quadrigaCADbuy');
const quadrigaCADsell = document.getElementById('quadrigaCADsell');

const quadrigaCAD = (function setQuadrigaCXCAD() {
  const XHR = new XMLHttpRequest();

  XHR.onreadystatechange = function setPrice() {
    if (XHR.readyState === 4) {
      const buyPrice = parseFloat(JSON.parse(XHR.responseText).ask).toFixed(2);
      const sellPrice = (buyPrice * 0.945).toFixed(2);
      quadrigaCADbuy.innerHTML = `<p class="h4"><span class="font-weight-bold">Sell price:</span><span class="text-monospace"> $${buyPrice} CAD/BTC</span></p>`;
      quadrigaCADsell.innerHTML = `<p class="h4"><span class="font-weight-bold">Buy price:</span><span class="text-monospace"> $${sellPrice} CAD/BTC</span></p>`;
      quadrigaCADbuy.value = buyPrice;
      quadrigaCADsell.value = sellPrice;

      btcQuantitybuyer.innerHTML = `<samp class="text-monospace h3">${(0.0000).toFixed(4)} BTC  </samp>`;
      btcQuantityseller.innerHTML = `<samp class="text-monospace h3">${(0.0000).toFixed(4)} BTC  </samp>`;
    }
  };

  XHR.open('GET', 'https://api.quadrigacx.com/v2/ticker?book=btc_cad');
  XHR.send();
  return XHR;
}());


buyerInputCAD.onkeyup = () => {
  if (quadrigaCAD.XHR.readyState === 4) {
    btcQuantitybuyer.innerHTML = `<samp class="text-monospace h3">${(_.floor((buyerInputCAD.value / quadrigaCAD.value), 3)).toFixed(4)} BTC  </samp> </samp>`;
  }
};

sellerInputCAD.onkeyup = () => {
  if (quadrigaCAD.XHR.readyState === 4) {
    btcQuantityseller.innerHTML = `<samp class="text-monospace h3">${(_.floor((sellerInputCAD.value / quadrigaCAD.value), 3)).toFixed(4)} BTC  </samp> </samp>`;
  }
};

// (function setCoindeskUSD() {
//   const XHR = new XMLHttpRequest();

//   XHR.onreadystatechange = function setPrice() {
//     if (XHR.readyState === 4) {
//       const price = JSON.parse(XHR.responseText).bpi.USD.rate_float.toFixed(2);
//       document.getElementById('coindeskUSD').innerText = price;
//     }
//   };

//   XHR.open('GET', 'https://api.coindesk.com/v1/bpi/currentprice.json');
//   XHR.send();
// }());
// (function setQuadrigaCXUSD() {
//   const XHR = new XMLHttpRequest();

//   XHR.onreadystatechange = function setPrice() {
//     if (XHR.readyState === 4) {
//       const price = ((parseFloat(JSON.parse(XHR.responseText).ask)
//         + (parseFloat(JSON.parse(XHR.responseText).bid))) / 2).toFixed(2);
//       document.getElementById('quadrigaUSD').innerText = price;
//     }
//   };

//   XHR.open('GET', 'https://api.quadrigacx.com/v2/ticker?book=btc_usd');
//   XHR.send();
// }());
