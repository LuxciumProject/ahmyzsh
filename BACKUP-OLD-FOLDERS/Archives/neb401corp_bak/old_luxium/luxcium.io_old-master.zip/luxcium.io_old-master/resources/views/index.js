
module.exports = require('./home/');
