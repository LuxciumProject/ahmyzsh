const fs = require('fs');
// const minifier = require('html-minifier');
const Minimize = require('minimize');
// const uglifycss = require('uglifycss');
const CleanCSS = require('clean-css');
// const uglifyJS = require('uglify-es');

const config = require('../../../config');
// const setHTTPheaders = require('../setHTTPheaders');

let head = '';
fs.readFile(`${__dirname}/head.html`, (err, data) => {
  head = data;
});
let cssFile = '';
fs.readFile(`${__dirname}/style.css`, (err, data) => {
  cssFile = data;
});
let topNavigation = '';
fs.readFile(`${__dirname}/topNavigation.html`, (err, data) => {
  topNavigation = data;
});
let mainContent = '';
fs.readFile(`${__dirname}/mainContent.html`, (err, data) => {
  mainContent = data;
});
let footer = '';
fs.readFile(`${__dirname}/footer.html`, (err, data) => {
  footer = data;
});
let scriptsInclude = '';
fs.readFile(`${__dirname}/scriptsInclude.html`, (err, data) => {
  scriptsInclude = data;
});
let jsFile = '';
fs.readFile(`${__dirname}/script.js`, (err, data) => {
  jsFile = data;
});

const prs = function parsing(text) {
  const textprsed = String(text);
  return textprsed.replace(/{version}/ig, config.internalVersion);
};

function createDocumentFromSources(file) {
  const next = fs.createWriteStream(file);
  next.write('<!DOCTYPE html>\n<html lang="en">\n<head>\n');
  next.write(prs(head));
  next.write('<style id="customInternalCSS" type="text/css">');
  // next.write(uglifycss.processFiles(`${__dirname}/home.css`));
  const cssString = new CleanCSS().minify(cssFile).styles.toString();
  next.write(cssString.toString());
  next.write('</style>\n');
  next.write('</head>\n<body>\n');
  next.write('<div id="site-wrapper" class="container-fluid">');
  next.write(prs(topNavigation));
  next.write(prs(mainContent));
  next.write(prs(footer));
  next.write(prs(scriptsInclude));
  next.write('<script id="customInternalJavaScript" type="application/javascript">');
  next.write(jsFile);
  next.write('</script>');
  next.write('</div>\n</body>\n</html>\n');
  next.end();
  return next;
}

setTimeout(() => {
  createDocumentFromSources(`${__dirname}/dist/home.html`);
}, 100);
setTimeout(() => {
  fs.readFile(`${__dirname}/dist/home.html`, (err, data) => {
    const myHtmlFile = `${__dirname}/dist/home.min.html`;
    const next = fs.createWriteStream(myHtmlFile);
    next.end(new Minimize().parse(data));
  });
}, 200);
