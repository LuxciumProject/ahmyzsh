const fs = require('fs');
const _ = require('lodash');
const config = require('../../../config');
const setHTTPheaders = require('../setHTTPheaders');

// const distFile = {
//   hasData: false,
//   hasErrors: true,
//   data: '',
//   error: '',
// };

// fs.readFile(`${__dirname}/dist/home.min.html`, (err, data) => {
// });

const prs = function parsing(text) {
  // const textprsed = String(text);
  const version = config.internalVersion;
  return _.replace(text, /{version}/ig, version);// textprsed.replace(/{version}/ig, config.internalVersion);
};

let head = '';
fs.readFile(`${__dirname}/head.html`, (err, data) => {
  head = prs(data);
});
let cssFile = '';
fs.readFile(`${__dirname}/style.css`, (err, data) => {
  cssFile = data;
});
let topNavigation = '';
fs.readFile(`${__dirname}/topNavigation.html`, (err, data) => {
  topNavigation = prs(data);
});
let mainContent = '';
fs.readFile(`${__dirname}/mainContent.html`, (err, data) => {
  mainContent = prs(data);
});
let footer = '';
fs.readFile(`${__dirname}/footer.html`, (err, data) => {
  footer = prs(data);
});
let scriptsInclude = '';
fs.readFile(`${__dirname}/scriptsInclude.html`, (err, data) => {
  scriptsInclude = prs(data);
});
let jsFile = '';
fs.readFile(`${__dirname}/script.js`, (err, data) => {
  jsFile = data;
});

module.exports = function returnHtmlParsed(res, done) {
  setHTTPheaders(res, (next) => {
    next.write('<!DOCTYPE html>\n<html lang="en">\n<head>\n');
    next.write(head);
    next.write('<!-- Luxcium.io CSS -->\n');
    next.write('<style id="customInternalCSS" type="text/css">\n');
    next.write(cssFile);
    next.write('</style>\n');
    next.write('</head>\n<body>\n');
    next.write('<div id="site-wrapper" class="container-fluid">\n');
    next.write(topNavigation);
    next.write('<div id="mainContent" class="container-fluid">\n');
    next.write('  <div id="mainContentSection">\n');
    next.write(mainContent);
    next.write('  </div>\n');
    next.write('</div>\n');
    next.write(footer);
    next.write(scriptsInclude);
    next.write('<script id="customInternalJavaScript" type="application/javascript">\n');
    next.write(jsFile);
    next.write('</script>\n');
    next.write('</div>\n</body>\n</html>\n');
    done(next);
  });
};

// function writeHtmlDistFile(res, done) {
//   setHTTPheaders(res, (next) => {
//     next.write(distFile.data);
//     done(next);
//   });
// }
