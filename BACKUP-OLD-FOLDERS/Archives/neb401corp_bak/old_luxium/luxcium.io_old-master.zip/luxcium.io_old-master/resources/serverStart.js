// #region [ HEAD ]
const express = require('express');
const configs = require('../config');
const router = require('./routes');

const app = express();
const version = configs.internalVersion;

// #endregion [ HEAD ]
// #region [ Main ]

module.exports = function serverStart(listeningPort) {
  const port = listeningPort || configs.PORT;
  app.use('/', express.static(`${__dirname}/public`));
  app.use(`/res/${version}`, express.static(`${__dirname}/../public/res/`));

  app.use('/', router);


  app.listen((process.env.PORT || port), () => {
    if (app.get('env') === 'development') {
      console.log('Express running mode set to development');
      console.log(`Listening on port: ${process.env.PORT || port}  . . . `);
    }
  });
};

// #endregion
