module.exports = {

  internalVersion: '0.0.0.52',
  PORT: 9080,
  connectionString: 'mongodb://localhost:27017/',
};
