const serverStart = require('./resources/serverStart');

serverStart(9080);
