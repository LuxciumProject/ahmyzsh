# luxcium.io
## Scientia is lux principium™


[![Build Status](https://semaphoreci.com/api/v1/projects/82413025-6964-4c9b-9a19-4a9b7441ec7f/2175825/shields_badge.svg)](https://semaphoreci.com/luxcium-32/master-luxcium-io)

