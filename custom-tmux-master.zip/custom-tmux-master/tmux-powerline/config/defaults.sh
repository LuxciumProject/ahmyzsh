# Default values for non segment configuration options.

export TMUX_POWERLINE_DEBUG_MODE_ENABLED_DEFAULT="false"
export TMUX_POWERLINE_PATCHED_FONT_IN_USE_DEFAULT="true"
export TMUX_POWERLINE_THEME_DEFAULT="default"
