// convert to 256
const hexStrToConvert = ""
