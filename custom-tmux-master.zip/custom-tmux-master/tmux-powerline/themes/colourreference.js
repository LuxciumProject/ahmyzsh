
/*
    colour0    "terminal.ansiBlack": "#221B25",
    colour1    "terminal.ansiRed": "#CC241D",
    colour2    "terminal.ansiGreen": "#98971A",
    colour3    "terminal.ansiYellow": "#E7A931",
    colour4    "terminal.ansiBlue": "#458588",
    colour5    "terminal.ansiMagenta": "#B16286",
    colour6    "terminal.ansiCyan": "#689D6A",
    colour7    "terminal.ansiWhite": "#C0B0A0",

    colour8    "terminal.ansiBrightBlack": "#928374",
    colour9    "terminal.ansiBrightRed": "#F42C3E",
    colour10    "terminal.ansiBrightGreen": "#B5C033",
    colour11    "terminal.ansiBrightYellow": "#FABD2F",
    colour12    "terminal.ansiBrightBlue": "#99C6CA",
    colour13    "terminal.ansiBrightMagenta": "#D66282",
    colour14    "terminal.ansiBrightCyan": "#8AE180",
    colour15    "terminal.ansiBrightWhite": "#DDCCAA",
*/

/*
    "terminalCursor.foreground": "#C02030",
    "terminalCursor.background": "#29153A",

    "terminal.background": "#221D25",
    "terminal.border": "#77116633",
    "terminal.foreground": "#DDBC9A",
    "terminal.selectionBackground": "#3277"
*/
