# SYNOPSIS         top
#      tmux [-2CluvV] [-c shell-command] [-f file] [-L socket-name]
#           [-S socket-path] [command [flags]]
