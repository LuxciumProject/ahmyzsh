# COLOPHON         top
#      This page is part of the tmux (terminal multiplexer) project.  Informa‐
#      tion about the project can be found at https://tmux.github.io/.  If you
#      have a bug report for this manual page, send it to
#      tmux-users@googlegroups.com.  This page was obtained from the project's
#      upstream Git repository ⟨https://github.com/tmux/tmux.git⟩ on
#      2019-11-19.  (At that time, the date of the most recent commit that was
#      found in the repository was 2019-11-18.)  If you discover any rendering
#      problems in this HTML version of the page, or you believe there is a
#      better or more up-to-date source for the page, or you have corrections
#      or improvements to the information in this COLOPHON (which is not part
#      of the original manual page), send a mail to man-pages@man7.org
