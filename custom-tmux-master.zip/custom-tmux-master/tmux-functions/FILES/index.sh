# FILES         top
#      ~/.tmux.conf               Default tmux configuration file.
#      @SYSCONFDIR@/tmux.conf     System-wide configuration file.
